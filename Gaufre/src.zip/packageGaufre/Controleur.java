package packageGaufre;

import java.awt.Point;
import java.io.*;
import IHM.*;
import javax.print.attribute.standard.DocumentName;
import javax.swing.SwingUtilities;

import joueur.*;

public class Controleur implements java.io.Serializable {

	Model donneesJeu;
	FenetreMenu fm;
	FenetreJeu fj;
	boolean attentecontroleur;

	public Controleur(int lignes,int colonnes) {
                Joueur[] tabJ = new Joueur[2];
		fm = new FenetreMenu();
		fj = new FenetreJeu(this);
                donneesJeu = new Model(lignes, colonnes, tabJ);
	}

	public boolean partieFinie() {

		boolean partieFinie;

		if (donneesJeu.tabGaufre[0][1] == false && donneesJeu.tabGaufre[1][0] == false) {
			partieFinie = true; // le process du jeu consiste à supprimer du
								// coin gauche en bas à droite. Du coup si ces
								// deux cases sont vides,
								// cela signifie que toute la gaufre est mangee
		} else {
			partieFinie = false;
		}

		return partieFinie;

	}

	public boolean coupEstValide(Point pointJouee) {
		return donneesJeu.getCase(pointJouee);
	}

	public Model getDonneesJeu() {
		return donneesJeu;
	}

	public boolean[][] creationTableauHistoriquePlateauJeu() {

		boolean[][] tabGaufreHistorique = new boolean[donneesJeu.lignes][donneesJeu.colonnes];

		boolean[][] tabCourante = donneesJeu.getTabGaufre();

		for (int i = 0; i < donneesJeu.lignes; i++) {
			for (int j = 0; j < donneesJeu.colonnes; j++) {
				tabGaufreHistorique[i][j] = tabCourante[i][j];
			}
		}

		return tabGaufreHistorique;

	}

	public void annuler() {
		donneesJeu.annuler();
	}

	public void refaire() {
		donneesJeu.refaire();
	}

	public void moteur() {
		//afficherPlateauJeu(); // fonction personnelle de vue
		SwingUtilities.invokeLater(fm);
		attentecontroleur=true;
		while (attentecontroleur) {
			//Une fois que nouvellePartie() ou charger() s'est lancé, l'attente se termine
		}
                fm.getFrame().setVisible(false);
		SwingUtilities.invokeLater(fj);
                attentecontroleur=true;
		while (!partieFinie() && attentecontroleur) {
                    
		}

		//donneesJeu.listeAnnuler.add(creationTableauHistoriquePlateauJeu());
		// ici la partie est finie donc le joueur suivant a perdu. Ce joueur est
		// incremente en fin de boucle donc c est ok
		//System.out.println("le joueur numero : " + donneesJeu.getJoueurCourant() + " a perdu");

		// System.out.println("Affichage des valeurs dans le sens inverse pour
		// verifier que stockage ok");
		// for (int i = donneesJeu.listeAnnuler.size() - 1; i >= 0; i--) {
		// System.out.println("Affichage un cran avant");
		// afficherPlateauJeuAvecParametre(donneesJeu.listeAnnuler.get(i));
		// }

		// System.out.println("--------");
		// afficherPlateauJeu();
		// this.annuler();
		// this.annuler();
		// this.refaire();
		// afficherPlateauJeu();
		// System.out.println("--------");

	}

	// vue temporaire pour tests persos
	public void afficherPlateauJeu() {
		for (int i = 0; i < donneesJeu.lignes; i++) {
			for (int j = 0; j < donneesJeu.colonnes; j++) {

				if (i == 0 && j == 0) {
					System.out.print("O");
				} else if (donneesJeu.tabGaufre[i][j]) {
					System.out.print("X");
				} else {
					System.out.print("=");
				}

			}
			System.out.println();
		}

		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

	}

	public void afficherPlateauJeuAvecParametre(boolean[][] gaufrinette) {
		for (int i = 0; i < donneesJeu.lignes; i++) {
			for (int j = 0; j < donneesJeu.colonnes; j++) {

				if (i == 0 && j == 0) {
					System.out.print("O");
				} else if (gaufrinette[i][j]) {
					System.out.print("X");
				} else {
					System.out.print("=");
				}

			}
			System.out.println();
		}

		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();

	}

	public void sauvegarder() {

		ObjectOutputStream oos = null;

		try {
			final FileOutputStream fichier = new FileOutputStream("donneesJeu.ser");
			oos = new ObjectOutputStream(fichier);
			oos.writeObject(donneesJeu);
			oos.flush();
		} catch (final java.io.IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (oos != null) {
					oos.flush();
					oos.close();
				}
			} catch (final IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void charger() {
		ObjectInputStream ois = null;
		try {
			final FileInputStream fichierIn = new FileInputStream("donneesJeu.ser");
			ois = new ObjectInputStream(fichierIn);
			donneesJeu = (Model) ois.readObject();
		} catch (final java.io.IOException e) {
			e.printStackTrace();
		} catch (final ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
			} catch (final IOException ex) {
				ex.printStackTrace();
			}
		}
		attentecontroleur = false;
	}

	public void nouvellePartie(int[] choix) {
		for (int i=0;i<choix.length;i++) {
			switch (choix[i]){
                            case 0 : donneesJeu.tabJoueurs[i] = new Humain();
                            case 1 : donneesJeu.tabJoueurs[i] = new IAFacile(this, 1000);
                            case 2 : donneesJeu.tabJoueurs[i] = new IAMoyen(this, 1000);
                            case 3 : donneesJeu.tabJoueurs[i] = new IADifficile(this, 1000);
                        }
		}
		//finaliser creer modele
		attentecontroleur = false;
	}
                
        public void nouvellePartieEnJeu() {
                attentecontroleur=false;
                moteur();
        }
}