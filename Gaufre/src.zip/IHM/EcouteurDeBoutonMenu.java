/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IHM;

import packageGaufre.Controleur;
import java.awt.event.*;
import static java.lang.System.exit;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JRadioButton;

class EcouteurDeBoutonMenu implements ActionListener {

    private Controleur c;
    private JRadioButton[] gr1;
    private JRadioButton[] gr2;

    public EcouteurDeBoutonMenu(Controleur c, JRadioButton[] gr1, JRadioButton[] gr2) {
        this.c = c;
        this.gr1 = gr1;
        this.gr2 = gr2;
    }

    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action.equals("Quitter")) {
            quitter();
        } else if (action.equals("Charger")) {
            charger();
        } else if (action.equals("Valider")) {
            valider();
        } else {
            System.out.println("Erreur Bouton");
        }
    }

    private void quitter() {
        exit(0);
    }

    private void valider() {
        int[] r = new int[2];
        for (int i = 0; i < gr1.length; i++) {
            if (gr1[i].isSelected()) {
                r[0] = i;
            }
        }
        for (int i = 0; i < gr2.length; i++) {
            if (gr2[i].isSelected()) {
                r[1] = i;
            }
        }
        c.nouvellePartie(r);
    }

    private void charger() {
        c.charger();
    }
}
