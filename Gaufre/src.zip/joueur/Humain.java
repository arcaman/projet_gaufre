package joueur;

import java.awt.Point;

public class Humain extends Joueur{

	@Override
	public Point jouer() {
		// TODO Auto-generated method stub
		return null;
	}

}
