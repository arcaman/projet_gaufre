package joueur;

import packageGaufre.*;

import java.awt.Point;

public class Joueur implements java.io.Serializable {

	public Controleur controleur;
	int temps;
	
	public Point jouer(){
		return null;
	}
	
	public boolean[][] listeVersTableau (boolean[] listeHautDroite){
		return null;
	}

	public boolean[] tableauVersListe (boolean[][] t){
		return null;
	}

}
